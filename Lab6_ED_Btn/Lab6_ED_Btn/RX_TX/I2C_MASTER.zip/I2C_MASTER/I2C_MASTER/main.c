#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>
#include <stdio.h>
#include "I2C/I2C.h"
#include "TIMER1/TIMER1.h"
#include "UART/UART_RECEIVER.h"
#include "HX711/HX711.h"


#include <stdlib.h>
#include <avr/interrupt.h>

#define SLAVE1      0x10
#define SLAVE2      0x20

#define SLAVE2_R   (0x20 << 1) | 0x01
#define SLAVE2_W   (0x20 << 1) & 0b11111110

#define SLAVE1_R   (0x10 << 1) | 0x01
#define SLAVE1_W   (0x10 << 1) & 0b11111110

uint8_t rxdato1;
volatile uint8_t step = 0;
volatile uint8_t flagstep = 0;
volatile uint8_t motorflag = 0;
uint8_t rawdata1 = 0;
uint8_t rawdata2 = 0;
uint8_t rawdata3 = 0;
int32_t datosprocesados = 0;
HX711_Cal cal = {.offset = 0, .scale = 420.0f};
float masa = 0;
uint8_t tare_flag = 0;
char buffer[20];
char out[40];
char masa_str[16];

uint8_t listo = 0; // indica que se ley� la b�scula

// -----------------------------------------------------------------------------
// 1) "MILLIS" con TIMER0 (no bloqueante)
// -----------------------------------------------------------------------------
static volatile uint32_t g_ms = 0;

static void timer0_millis_init(void)
{
    // Timer0 CTC -> interrupci�n cada 1 ms
    TCCR0A = (1<<WGM01);                 // CTC
    TCCR0B = (1<<CS01) | (1<<CS00);      // prescaler 64
    OCR0A  = 249;                        // 16MHz/64 = 250kHz -> 250 ticks = 1ms -> 249
    TIMSK0 = (1<<OCIE0A);                // habilita interrupci�n compare A
}

ISR(TIMER0_COMPA_vect)
{
    g_ms++;
}

static uint32_t millis(void)
{
    uint32_t t;
    cli();
    t = g_ms;
    sei();
    return t;
}

// Devuelve 1 si ya pasaron "period_ms" desde la �ltima vez, si no devuelve 0.
// Actualiza autom�ticamente *last_ms cuando se cumple.
static uint8_t timer_elapsed_ms(uint32_t *last_ms, uint32_t period_ms)
{
    uint32_t now = millis();
    if ((now - *last_ms) >= period_ms)
    {
        *last_ms = now;
        return 1;
    }
    return 0;
}

// -----------------------------------------------------------------------------
// 2) Funci�n: pedir 3 bytes al SLAVE2 y decodificar muestra HX711
//    - Importante: aqu� NO salimos de main. Si falla I2C, devolvemos 0.
// -----------------------------------------------------------------------------
static uint8_t HX711_request_sample_from_slave(void)
{
    // Inicia comunicaci�n
    if(!I2C_Master_Start()) return 0;

    if(!I2C_Master_Write(SLAVE2_W))
    {
        I2C_Master_Stop();
        return 0;
    }

    // Comando al slave: "W" = quiero peso
    I2C_Master_Write('W');

    // Repeated start para leer
    if(!I2C_Master_RepeatedStart())
    {
        I2C_Master_Stop();
        return 0;
    }

    if(!I2C_Master_Write(SLAVE2_R))
    {
        I2C_Master_Stop();
        return 0;
    }

    // Lee 3 bytes (ACK, ACK, NACK)
    I2C_Master_Read(&rawdata1, 1);
    I2C_Master_Read(&rawdata2, 1);
    I2C_Master_Read(&rawdata3, 0);

    I2C_Master_Stop();
    return 1;
}

// -----------------------------------------------------------------------------
// 3) Funci�n: mandar comando al SLAVE2 para mover servo
// -----------------------------------------------------------------------------
/*static uint8_t send_servo_command_to_slave(void)
{
    if(!I2C_Master_Start()) return 0;

    if(!I2C_Master_Write(SLAVE2_W))
    {
        I2C_Master_Stop();
        return 0;
    }

    
    I2C_Master_Write('S');

    I2C_Master_Stop();
    return 1;
} */

// -----------------------------------------------------------------------------
// 4) FSM (m�quina de estados) del master
// -----------------------------------------------------------------------------
typedef enum {
    ST_PESANDO = 0,        // Pide muestras del HX711 y eval�a condici�n
    ST_MOVER_SERVO,        // Env�a bandera/comando al slave para mover servo
    ST_SENSOR_IR,          // Contin�a con el resto del sistema (ya NO lee b�scula)
    STEPPER,
    SENSOR2_IR,
    LASER, 
    
    
} estado_t;

int main(void)
{
    UART_RECEIVER(103);
    I2C_Master_Init(100000, 1);

    DDRB |= (1<<DDB5);
    DDRC |= (1<<DDC1);
    PORTC &= ~(1<<PORTC1);

    // Inicia millis
    timer0_millis_init();
    sei();

    // Opcional: inicia tare desde 0 (t� ya lo ten�as)
    HX711_tare_fromRaw(&cal, datosprocesados);

    // -------------------------
    // CONFIG del comportamiento
    // -------------------------
    const float THRESH_G = 100.0f;         // umbral de disparo
    const uint8_t N_OK_CONSEC = 20;       // # lecturas consecutivas arriba de umbral
    const uint32_t SAMPLE_PERIOD_MS = 50;  // cada cu�nto pido una muestra al slave 

    estado_t estado = ST_PESANDO;

    uint8_t ok_count = 0;         // contador de lecturas consecutivas > THRESH
    uint32_t t_sample = 0;        // marca de tiempo para muestreo peri�dico

    while (1)
    {
        switch(estado)
        {
            // -------------------------------------------------------------
            // ESTADO 1: PESANDO
                        
            case ST_PESANDO:
            {
                // Solo muestrea cada SAMPLE_PERIOD_MS (no bloqueante)
                if(!timer_elapsed_ms(&t_sample, SAMPLE_PERIOD_MS))  // pido una muestra cada 50ms
                {
                    break;
                }

                // Pide una muestra al slave
                if(!HX711_request_sample_from_slave())
                {
                    // pido muestra al slave con SLA+W 
                    
                    break;
                }

                datosprocesados = HX711_decode24(rawdata1, rawdata2, rawdata3);
                if(tare_flag == 0)
                {
                    HX711_tare_fromRaw(&cal, datosprocesados);
                    tare_flag = 1;
                }

                masa = HX711_toUnits(&cal, datosprocesados);

                dtostrf(masa, 0, 2, masa_str);
                snprintf(out, sizeof(out), "Masa: %s g\r\n", masa_str);
                cadena(out);

                // Filtro simple: N lecturas consecutivas arriba del umbral
                if(masa >= THRESH_G) ok_count++;
                else ok_count = 0;

                // Si ya se cumpli� la condici�n con estabilidad
                if(ok_count >= N_OK_CONSEC)
                {
                    listo = 1;                // ya termin� etapa de b�scula
                    estado = ST_MOVER_SERVO;  // avanza al siguiente paso
                }

                break;
            }

            // -------------------------------------------------------------
            // ESTADO 2: MOVER SERVO
            
            case ST_MOVER_SERVO:
            
               /* if(!I2C_Master_Start()) return;
                
                if(!I2C_Master_Write(SLAVE2_W))
                {
                    I2C_Master_Stop();
                    return;
                }
                I2C_Master_Write('H');
                
                if(!I2C_Master_RepeatedStart())
                {
                    I2C_Master_Stop();
                    return;*/
                
                
            estado = STEPPER;           
            break;  
             
            
            case STEPPER:
            
                //Rutia para encender el stepper -------------------------------------------------------------------
                while(rxdato1 != 'D'){
                    if(!I2C_Master_Start()) return;
                    
                    if(!I2C_Master_Write(SLAVE1_W))
                    {
                        I2C_Master_Stop();
                        return;
                    }
                    I2C_Master_Write('D');
                    
                    if(!I2C_Master_RepeatedStart())
                    {
                        I2C_Master_Stop();
                        return;
                    }

                    if(!I2C_Master_Write(SLAVE1_R)){    // LEER SENSOR IR 1
                        I2C_Master_Stop();
                        return;
                    }
                    
                    I2C_Master_Read(&rxdato1,0);
                    I2C_Master_Stop();
                      
                }
                
                
                // para regresar el SERVO a posici�n original 
                /*if(!I2C_Master_Start()) return;
                
                if(!I2C_Master_Write(SLAVE2_W))
                {
                    I2C_Master_Stop();
                    return;
                }
                I2C_Master_Write('F');
                
                if(!I2C_Master_RepeatedStart())
                {
                    I2C_Master_Stop();
                    return;
                    }*/
                
                   

                    flagstep = 'O';     // inicia el stepper 
                    motorflag = 'L';   //VERIFICAR CON SENSOR LASER SI HAY QUE BAJARLO O NO
                    
                
                
                
                // para encender el STEPPER 
                if(!I2C_Master_Start()) return;

                if(!I2C_Master_Write(SLAVE2_W))
                {
                    I2C_Master_Stop();
                    return;
                }
                I2C_Master_Write(flagstep);
                I2C_Master_Stop();
             
             // para bajar el DC 
             // AGREGAR BANDERA DEL LASER PARA VERIFICAR SI HACE FALTA O NO 
                 if(!I2C_Master_Start()) return;

                 if(!I2C_Master_Write(SLAVE1_W))
                 {
                     I2C_Master_Stop();
                     return;
                 }
                 I2C_Master_Write(motorflag);
                 I2C_Master_Stop();
                 
                 estado = SENSOR2_IR;

            
            break;
            
            case SENSOR2_IR:
            
                // Esperamos a que el SENSOR2_IR detecte algo 
                while(rxdato1 != 'A'){
                    if(!I2C_Master_Start()) return;
                    
                    if(!I2C_Master_Write(SLAVE2_W))
                    {
                        I2C_Master_Stop();
                        return;
                    }
                    I2C_Master_Write('S');
                    
                    if(!I2C_Master_RepeatedStart())
                    {
                        I2C_Master_Stop();
                        return;
                    }

                    if(!I2C_Master_Write(SLAVE2_R)){    // LEER SENSOR IR 1
                        I2C_Master_Stop();
                        return;
                    }
                    
                    I2C_Master_Read(&rxdato1,0);
                    I2C_Master_Stop();
                   
                    
                    
                }
                
                
                // Si SENSOR2_IR ya detect� algo, entonces...
                
                if(rxdato1 == 'A'){
                    flagstep = 'K';
                    motorflag = 'M';
                }
               
                //RUTINA PARA APAGAR STEPPER   
                
                if(!I2C_Master_Start()) return;
                
                if(!I2C_Master_Write(SLAVE2_W))
                {
                    I2C_Master_Stop();
                    return;
                }

                I2C_Master_Write(flagstep);
                I2C_Master_Stop();
                
                //RUTINA PARA ENCENDER EL ELEVADOR
                if(!I2C_Master_Start()) return;
                
                if(!I2C_Master_Write(SLAVE1_W))
                {
                    I2C_Master_Stop();
                    return;
                }
                I2C_Master_Write(motorflag);
                I2C_Master_Stop();
            }

                
            
            }
                           
                            
                                          
    
}
